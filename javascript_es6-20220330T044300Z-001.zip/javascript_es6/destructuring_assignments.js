var foo = ['one', 'two', 'three'];

var [abc, wxy, efg] = foo;

console.log(abc); // "one"
console.log(wxy); // "two"
console.log(efg); // "three"